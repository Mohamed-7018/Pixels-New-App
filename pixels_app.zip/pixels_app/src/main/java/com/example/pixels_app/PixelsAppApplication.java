package com.example.pixels_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PixelsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PixelsAppApplication.class, args);
	}

}
